﻿namespace TEC_P1_C__Slut_opgave
{
    class Program
    {


        static void Main(string[] args)
        {
           

            Game game = new Game();


            game.Run();
        }










    }
}
