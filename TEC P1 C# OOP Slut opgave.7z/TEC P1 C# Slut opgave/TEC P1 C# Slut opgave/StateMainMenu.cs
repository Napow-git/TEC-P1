﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEC_P1_C__Slut_opgave
{
    class StateMainMenu : State
    {
        public StateMainMenu(Stack<State> states)
            : base(states) 
        {
     
        }
        override public void Update()
        {



        }



    }
}
