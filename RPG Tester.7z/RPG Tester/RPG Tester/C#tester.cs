﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace RPG_Tester
{
    class Circle
    {
        private double radiusCM;
        public double RadiusMeters
        {
            get { return radiusCM / 100; }
            set { radiusCM = value * 100; } 

        }
    
        class Program 
        { 
            static void Main(string[] args)
            { 
                Circle myCircle = new Circle();
                myCircle.RadiusMeters = 50;
                double radius = myCircle.RadiusMeters;

            }


        }    


    }
}
