﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Tester.States
{
    class StateGame : State
    {
    
    public StateGame(Stack<State> stack) 
        : base(stack) 
        {
       

        }

    }
}
