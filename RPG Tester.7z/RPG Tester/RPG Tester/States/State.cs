﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Tester
{

    class State
    {
        public Stack<State> states;
        bool end = false;

        public State(Stack<State> states)
        {
            this.states = states;

          
        }
        virtual public void Update()
        { 

        }


    }

}
