﻿using RPG_Tester.GUI;
using RPG_Tester.States;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG_Tester
{
    class Game
    {
        private bool end;

       

        public bool End

        {
            get { return this.end; }
            set { this.end = value; }
        }

        

        private Stack<State> states;
    
        private void initVariables() 
        {

            this.end = false;
        }
        private void initStates()
        {
        this.states = new Stack<State>();

        this.states.Push(new StateMainMenu(this.states));
            
        }

     
        public Game() 
        
        { 
            this.initVariables();
            this.InitState();
            
        }
        private void InitState()

        {
            this.states = new Stack<State>();
            //Console.WriteLine(states.GetHashCode());  

            this.states.Push(new State(this.states)); 

        
        }

    

        public void Run() 
        { 
            while(this.end == false)
            {
                if(this.states.Count > 0)
                this.states.Peek().Update();

                
            }
            Console.WriteLine("Ending game...");
        }
    }
}
